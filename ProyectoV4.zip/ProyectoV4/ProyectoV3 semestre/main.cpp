#include <iostream>
#include <string>
#include <fstream>
#include <sstream>   // Para separar las lineas de los archivos
#include <ctime>      // Para la fecha en planilla.txt
#include <iomanip>   
#include <vector>    
#include <limits>    // Para limpiar el buffer en caso de error

#include "ListaEmpleados.h"
#include "Medico.h"
#include "Enfermero.h"
#include "Administrador.h"

using namespace std;

// =====================================================================
// FUNCIONES DE VALIDACI�N
// =====================================================================

int leerEntero(string mensaje) {
	int valor;
	while (true) {
		cout << mensaje;
		if (cin >> valor) {
			cin.ignore(numeric_limits<streamsize>::max(), '\n'); 
			return valor;
		} else {
			cout << ">> ERROR: Debe ingresar un numero entero valido. Intente de nuevo.\n";
			cin.clear(); 
			cin.ignore(numeric_limits<streamsize>::max(), '\n'); 
		}
	}
}

double leerDouble(string mensaje) {
	double valor;
	while (true) {
		cout << mensaje;
		if (cin >> valor) {
			cin.ignore(numeric_limits<streamsize>::max(), '\n');
			return valor;
		} else {
			cout << ">> ERROR: Debe ingresar un numero (puede tener decimales). Intente de nuevo.\n";
			cin.clear();
			cin.ignore(numeric_limits<streamsize>::max(), '\n');
		}
	}
}

string leerTexto(string mensaje) {
	string valor;
	while (true) {
		cout << mensaje;
		getline(cin, valor);
		if (!valor.empty()) {
			return valor;
		} else {
			cout << ">> ERROR: El campo no puede estar vacio. Intente de nuevo.\n";
		}
	}
}

// =====================================================================
// CARGA AUTOMATICA DE ARCHIVOS (se ejecuta al iniciar el programa)
// =====================================================================

// Lee empleados.txt y crea los objetos con los constructores existentes.
// Formato de cada linea (campos separados por '|'):
//   M|cedula|nombre|salarioBase|guardiasRealizadas|pagoPorGuardia
//   E|cedula|nombre|salarioBase|guardiasNocturnas|horasExtra
//   A|cedula|nombre|salarioBase|horasExtra
void cargarEmpleados(ListaEmpleados& lista) {
	ifstream archivo("empleados.txt");
	if (!archivo.is_open()) return;   // si no existe, el programa arranca vacio
	
	string linea;
	while (getline(archivo, linea)) {
		if (!linea.empty() && linea[linea.size() - 1] == '\r') linea.erase(linea.size() - 1); // por si el archivo viene de Windows
		if (linea.empty()) continue;
		
		vector<string> c;
		stringstream ss(linea);
		string campo;
		while (getline(ss, campo, '|')) c.push_back(campo);
		
		try {
			if (c.size() < 5 || lista.buscarPorId(c[1]) != nullptr) continue;
			double base = stod(c[3]);
			
			if (c[0] == "M" && c.size() == 6)
				lista.agregar(new Medico(c[1], c[2], base, stoi(c[4]), stod(c[5])));
			else if (c[0] == "E" && c.size() == 6)
				lista.agregar(new Enfermero(c[1], c[2], base, stoi(c[4]), stoi(c[5])));
			else if (c[0] == "A" && c.size() == 5)
				lista.agregar(new Administrador(c[1], c[2], base, stoi(c[4])));
		} catch (...) {
		}
	}
}

// Para departamentos.txt y planilla.txt: carga cada linea como texto
vector<string> cargarLineas(string ruta) {
	vector<string> lineas;
	ifstream archivo(ruta.c_str());
	string linea;
	while (getline(archivo, linea)) {
		if (!linea.empty() && linea[linea.size() - 1] == '\r') linea.erase(linea.size() - 1);
		if (!linea.empty()) lineas.push_back(linea);
	}
	return lineas;
}

// =====================================================================
// GUARDADO AUTOMATICO EN ARCHIVOS (agrega una linea al final del archivo)
// =====================================================================

// Cambia '|' por espacio para que no rompa el formato del archivo
string sinBarras(string s) {
	for (size_t i = 0; i < s.size(); i++)
		if (s[i] == '|') s[i] = ' ';
	return s;
}

// Convierte un numero a texto con 2 decimales (evita notacion cientifica)
string numero(double v) {
	ostringstream o;
	o << fixed << setprecision(2) << v;
	return o.str();
}

string fechaActual() {
	time_t t = time(nullptr);
	char buf[20];
	strftime(buf, sizeof(buf), "%Y-%m-%d %H:%M", localtime(&t));
	return string(buf);
}

// Agrega una linea al final del archivo (lo crea si no existe)
bool agregarLineaArchivo(string ruta, string linea) {
	ofstream archivo(ruta.c_str(), ios::app);
	if (!archivo.is_open()) {
		cout << "ERROR: no se pudo guardar en " << ruta << ".\n";
		return false;
	}
	archivo << linea << "\n";
	return true;
}

// =====================================================================
// L�GICA DEL SISTEMA
// =====================================================================

void registrarEmpleado(ListaEmpleados& lista) {
	cout << "\n--- REGISTRAR EMPLEADO ---\n";
	
	string id = leerTexto("Ingrese Cedula: ");
	
	// Validar que no exista
	if (lista.buscarPorId(id) != nullptr) {
		cout << "ERROR: Ya existe un empleado con la cedula " << id << ".\n";
		return;
	}
	
	string nombre = leerTexto("Ingrese Nombre: ");
	
	int tipoEmpleado = 0;
	do {
		cout << "\nSeleccione el tipo de empleado:\n";
		cout << "  1. Medico\n";
		cout << "  2. Enfermero\n";
		cout << "  3. Administrativo\n";
		tipoEmpleado = leerEntero("Opcion: ");
		if (tipoEmpleado < 1 || tipoEmpleado > 3) {
			cout << ">> ERROR: Opcion fuera de rango (1-3).\n";
		}
	} while (tipoEmpleado < 1 || tipoEmpleado > 3);
	
	switch (tipoEmpleado) {
	case 1: {
		cout << "\n--- Registro de Medico ---\n";
		double salarioBase = leerDouble("Ingrese Salario Base: ");
		int guardiasRealizadas = leerEntero("Ingrese Cantidad de Guardias Realizadas: ");
		double pagoPorGuardia = leerDouble("Ingrese Pago por Guardia: ");
		
		Medico* nuevoMedico = new Medico(id, nombre, salarioBase, guardiasRealizadas, pagoPorGuardia);
		lista.agregar(nuevoMedico);
		cout << "\n[OK] Medico agregado correctamente.\n";
		if (agregarLineaArchivo("empleados.txt", "M|" + id + "|" + sinBarras(nombre) + "|" + numero(salarioBase)
								+ "|" + to_string(guardiasRealizadas) + "|" + numero(pagoPorGuardia)))
			cout << "[OK] Guardado en empleados.txt\n";
		break;
	}
	case 2: {
		cout << "\n--- Registro de Enfermero ---\n";
		double salarioBase = leerDouble("Ingrese Salario Base: ");
		int guardiasNocturnas = leerEntero("Ingrese Cantidad de Guardias Nocturnas: ");
		int horasExtra = leerEntero("Ingrese Cantidad de Horas Extra: ");
		
		Enfermero* nuevoEnfermero = new Enfermero(id, nombre, salarioBase, guardiasNocturnas, horasExtra);
		lista.agregar(nuevoEnfermero);
		cout << "\n[OK] Enfermero agregado correctamente.\n";
		if (agregarLineaArchivo("empleados.txt", "E|" + id + "|" + sinBarras(nombre) + "|" + numero(salarioBase)
								+ "|" + to_string(guardiasNocturnas) + "|" + to_string(horasExtra)))
			cout << "[OK] Guardado en empleados.txt\n";
		break;
	}
	case 3: {
		cout << "\n--- Registro de Administrativo ---\n";
		double salarioBase = leerDouble("Ingrese Salario Base: ");
		int horasExtra = leerEntero("Ingrese Cantidad de Horas Extra: ");
		
		Administrador* nuevoAdmin = new Administrador(id, nombre, salarioBase, horasExtra);
		lista.agregar(nuevoAdmin);
		cout << "\n[OK] Administrativo agregado correctamente.\n";
		if (agregarLineaArchivo("empleados.txt", "A|" + id + "|" + sinBarras(nombre) + "|" + numero(salarioBase)
								+ "|" + to_string(horasExtra)))
			cout << "[OK] Guardado en empleados.txt\n";
		break;
	}
	}
}

void mostrarEmpleados(const ListaEmpleados& lista) {
	cout << "\n--- LISTA DE EMPLEADOS REGISTRADOS ---\n";
	lista.mostrar();
}

void mostrarPorProfesion(const ListaEmpleados& lista) {
	cout << "\n--- MOSTRAR POR PROFESION ---\n";
	cout << "1. Medicos\n2. Enfermeros\n3. Administrativos\n";
	
	int op = leerEntero("Opcion: ");
	system("cls");
	cout << fixed << setprecision(2);
	
	switch (op) {
	case 1: {
		vector<Medico*> medicos = lista.obtenerMedicos();
		if (medicos.empty()) { cout << "No hay medicos registrados.\n"; break; }
		cout << "\n--- MEDICOS ---\n";
		for (size_t i = 0; i < medicos.size(); i++) {
			Medico* m = medicos[i];
			cout << "ID: " << m->getId() << " | Nombre: " << m->getNombre()
				<< " | Bruto: " << m->calcularSalarioBruto() << " | Neto: " << m->calcularSalarioNeto() << endl;
		}
		break;
	}
	case 2: {
		vector<Enfermero*> enfermeros = lista.obtenerEnfermeros();
		if (enfermeros.empty()) { cout << "No hay enfermeros registrados.\n"; break; }
		cout << "\n--- ENFERMEROS ---\n";
		for (size_t i = 0; i < enfermeros.size(); i++) {
			Enfermero* e = enfermeros[i];
			cout << "ID: " << e->getId() << " | Nombre: " << e->getNombre()
				<< " | Bruto: " << e->calcularSalarioBruto() << " | Neto: " << e->calcularSalarioNeto() << endl;
		}
		break;
	}
	case 3: {
		vector<Administrador*> admins = lista.obtenerAdministradores();
		if (admins.empty()) { cout << "No hay administrativos registrados.\n"; break; }
		cout << "\n--- ADMINISTRATIVOS ---\n";
		for (size_t i = 0; i < admins.size(); i++) {
			Administrador* a = admins[i];
			cout << "ID: " << a->getId() << " | Nombre: " << a->getNombre()
				<< " | Bruto: " << a->calcularSalarioBruto() << " | Neto: " << a->calcularSalarioNeto() << endl;
		}
		break;
	}
	default: cout << "Opcion invalida.\n";
	}
}

void calcularSalario(const ListaEmpleados& lista) {
	cout << "\n--- CALCULO DE SALARIOS ---\n";
	string idBuscado = leerTexto("Ingrese la cedula del empleado: ");
	
	Empleado* emp = lista.buscarPorId(idBuscado);
	system("cls"); // Limpiamos la pantalla para mostrar los resultados limpios
	
	if (emp == nullptr) {
		cout << "No se encontro ningun empleado con la cedula: " << idBuscado << endl;
		return;
	}
	
	cout << fixed << setprecision(2);
	cout << "\nEmpleado encontrado:\n";
	cout << "Cedula:       " << emp->getId() << endl;
	cout << "Nombre:       " << emp->getNombre() << endl;
	cout << "Salario Base: " << emp->getSalarioBase() << endl;
	cout << "Salario Bruto:      " << emp->calcularSalarioBruto() << endl;
	cout << "Deducciones:        " << emp->calcularDeducciones() << endl;
	cout << "Salario Neto:       " << emp->calcularSalarioNeto() << endl;
	
	// Guarda el calculo en planilla.txt: cedula|fecha|bruto|deducciones|neto
	if (agregarLineaArchivo("planilla.txt", emp->getId() + "|" + fechaActual() + "|" + numero(emp->calcularSalarioBruto())
							+ "|" + numero(emp->calcularDeducciones()) + "|" + numero(emp->calcularSalarioNeto())))
		cout << "\n[OK] Calculo guardado en planilla.txt\n";
}

void guardarEnArchivo(const ListaEmpleados& lista) {
	cout << "\n--- GUARDAR DATOS EN ARCHIVO DE TEXTO ---\n";
	ofstream archivo("README.txt");
	if (!archivo.is_open()) {
		cout << "ERROR: no se pudo abrir el archivo.\n";
		return;
	}
	archivo << fixed << setprecision(2);
	for (int i = 0; i < lista.getTamano(); i++) {
		Empleado* emp = lista.obtener(i);
		if (emp != nullptr) {
			archivo << emp->getId() << "\n" << emp->getNombre() << "\n" << emp->getSalarioBase() << "\n----------------------\n";
		}
	}
	archivo.close();
	cout << "[OK] Datos guardados exitosamente en README.txt\n";
}

// =====================================================================
// MAIN
// =====================================================================

int main() {
	ListaEmpleados listaEmpleados;
	
	// Carga automatica de los archivos al iniciar
	cargarEmpleados(listaEmpleados);
	vector<string> departamentos = cargarLineas("departamentos.txt");
	vector<string> planilla = cargarLineas("planilla.txt");
	
	int opcion = 0;
	
	do {
		cout << "\n=========================================\n";
		cout << "    SISTEMA DE PLANILLA HOSPITALARIA     \n";
		cout << "=========================================\n";
		cout << "1. Registrar Nuevo Empleado\n";
		cout << "2. Mostrar Lista de Empleados\n";
		cout << "3. Mostrar por Profesion\n";
		cout << "4. Calcular y Ver Salarios\n";
		cout << "5. Guardar Datos en Archivo de Texto\n";
		cout << "6. Salir\n";
		
		opcion = leerEntero("Seleccione una opcion: ");
		
		// Limpia la pantalla despu�s de escoger una opci�n v�lida
		system("cls");
		
		switch (opcion) {
		case 1: registrarEmpleado(listaEmpleados);   break;
		case 2: mostrarEmpleados(listaEmpleados);    break;
		case 3: mostrarPorProfesion(listaEmpleados); break;
		case 4: calcularSalario(listaEmpleados);     break;
		case 5: guardarEnArchivo(listaEmpleados);    break;
		case 6: 
			cout << "\nSaliendo del sistema. �Hasta luego!\n"; 
			break;
		default: 
			cout << "\nERROR: Opcion invalida (1-6). Intente de nuevo.\n";
		}
		
		if (opcion != 6) {
			cout << "\nPresione ENTER para continuar...";
			cin.get();
			system("cls"); // Limpia la consola antes de volver a mostrar el men�
		}
	} while (opcion != 6);
	
	return 0;
}
