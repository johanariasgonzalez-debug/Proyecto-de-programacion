#ifndef NODOEMPLEADO_H
#define NODOEMPLEADO_H

#include "Empleado.h"

class NodoEmpleado {
private:
	Empleado* dato;          // Puntero a la clase base (polimorfismo)
	NodoEmpleado* siguiente;
	
public:
	// Constructor y Destructor
	NodoEmpleado(Empleado* emp);
	~NodoEmpleado();
	
	// Getters y Setters
	void setDato(Empleado* emp);
	Empleado* getDato() const;
	
	void setSiguiente(NodoEmpleado* sig);
	NodoEmpleado* getSiguiente() const;
};

#endif
