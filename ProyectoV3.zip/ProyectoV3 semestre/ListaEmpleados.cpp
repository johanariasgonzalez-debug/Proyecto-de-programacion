#include "ListaEmpleados.h"
#include <iostream>

using namespace std;

ListaEmpleados::ListaEmpleados() {
	cabeza = nullptr;
	tamano = 0;
}

ListaEmpleados::~ListaEmpleados() {
	NodoEmpleado* actual = cabeza;
	while (actual != nullptr) {
		NodoEmpleado* siguiente = actual->getSiguiente();
		delete actual;   
		actual = siguiente;
	}
}

bool ListaEmpleados::estaVacia() const { return cabeza == nullptr; }
int  ListaEmpleados::getTamano() const { return tamano; }

void ListaEmpleados::agregar(Empleado* nuevoEmpleado) {
	NodoEmpleado* nuevoNodo = new NodoEmpleado(nuevoEmpleado);
	if (estaVacia()) {
		cabeza = nuevoNodo;
	} else {
		NodoEmpleado* actual = cabeza;
		while (actual->getSiguiente() != nullptr)
			actual = actual->getSiguiente();
		actual->setSiguiente(nuevoNodo);
	}
	tamano++;
}

bool ListaEmpleados::eliminar(string id) {
	if (estaVacia()) return false;
	NodoEmpleado* actual = cabeza;
	NodoEmpleado* anterior = nullptr;
	
	while (actual != nullptr && actual->getDato()->getId() != id) {
		anterior = actual;
		actual = actual->getSiguiente();
	}
	if (actual == nullptr) return false;
	
	if (anterior == nullptr) cabeza = actual->getSiguiente();
	else anterior->setSiguiente(actual->getSiguiente());
	
	delete actual;   
	tamano--;
	return true;
}

Empleado* ListaEmpleados::obtener(int index) const {
	if (index < 0 || index >= tamano) return nullptr;
	NodoEmpleado* actual = cabeza;
	for (int i = 0; i < index && actual != nullptr; i++)
		actual = actual->getSiguiente();
	return actual ? actual->getDato() : nullptr;
}

void ListaEmpleados::mostrar() const {
	if (estaVacia()) {
		cout << "No hay empleados registrados.\n";
		return;
	}
	NodoEmpleado* actual = cabeza;
	while (actual != nullptr) {
		Empleado* e = actual->getDato();
		cout << "ID: " << e->getId() << " | Nombre: " << e->getNombre() << " | Salario Base: " << e->getSalarioBase() << endl;
		actual = actual->getSiguiente();
	}
}

Empleado* ListaEmpleados::buscarPorId(string id) const {
	NodoEmpleado* actual = cabeza;
	while (actual != nullptr) {
		if (actual->getDato()->getId() == id)
			return actual->getDato();
		actual = actual->getSiguiente();
	}
	return nullptr;
}

vector<Medico*> ListaEmpleados::obtenerMedicos() const {
	vector<Medico*> resultado;
	NodoEmpleado* actual = cabeza;
	while (actual != nullptr) {
		Medico* m = dynamic_cast<Medico*>(actual->getDato());
		if (m != nullptr) resultado.push_back(m);
		actual = actual->getSiguiente();
	}
	return resultado;
}

vector<Enfermero*> ListaEmpleados::obtenerEnfermeros() const {
	vector<Enfermero*> resultado;
	NodoEmpleado* actual = cabeza;
	while (actual != nullptr) {
		Enfermero* e = dynamic_cast<Enfermero*>(actual->getDato());
		if (e != nullptr) resultado.push_back(e);
		actual = actual->getSiguiente();
	}
	return resultado;
}

vector<Administrador*> ListaEmpleados::obtenerAdministradores() const {
	vector<Administrador*> resultado;
	NodoEmpleado* actual = cabeza;
	while (actual != nullptr) {
		Administrador* a = dynamic_cast<Administrador*>(actual->getDato());
		if (a != nullptr) resultado.push_back(a);
		actual = actual->getSiguiente();
	}
	return resultado;
}
