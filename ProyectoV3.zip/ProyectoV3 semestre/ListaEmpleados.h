#ifndef LISTAEMPLEADOS_H
#define LISTAEMPLEADOS_H

#include <string>
#include <vector>        // Necesario para los filtros
#include "NodoEmpleado.h"
#include "Medico.h"
#include "Enfermero.h"
#include "Administrador.h"

using namespace std;

class ListaEmpleados {
private:
	NodoEmpleado* cabeza;
	int tamano;
	
public:
	ListaEmpleados();
	~ListaEmpleados();
	
	bool estaVacia() const;
	int getTamano() const;
	
	void agregar(Empleado* nuevoEmpleado);
	bool eliminar(string id);
	Empleado* obtener(int index) const;
	void mostrar() const;
	
	// M�todos nuevos para el main
	Empleado* buscarPorId(string id) const;
	vector<Medico*> obtenerMedicos() const;
	vector<Enfermero*> obtenerEnfermeros() const;
	vector<Administrador*> obtenerAdministradores() const;
};

#endif
