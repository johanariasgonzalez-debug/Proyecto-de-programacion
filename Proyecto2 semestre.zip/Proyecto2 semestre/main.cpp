#include <iostream>
#include <string>
#include <fstream> //libreria de archivo
//Listas
#include "ListaMedico.h"
#include "ListaEnfermero.h"
#include "ListaEmpleados.h"
#include "ListaAdmin.h"
//Clases
#include "Medico.h"
#include "Enfermero.h"
#include "Administrador.h"

using namespace std;

int main() {

//llamar aqui funcion para registrar en la Lista
	ListaMedico listaMedicos;
	ListaEnfermero listaEnfermeros; //linea 85
	ListaAdmin listaAdmins;//Linea 107
	ListaEmpleados listaEmpleados;//linea 141
//llamar aqu� a la funci�n de carga autom�tica desde archivos de texto al iniciar

	
	int opcion = 0;
	
	do {
		cout << "\n=========================================\n";
		cout << "    SISTEMA DE PLANILLA HOSPITALARIA     \n";
		cout << "=========================================\n";
		cout << "1. Registrar Nuevo Empleado\n";
		cout << "2. Mostrar Lista de Empleados\n";
		cout << "3. Calcular y Ver Salarios\n";
		cout << "4. Guardar Datos en Archivo de Texto\n"; 
		cout << "5. Salir\n";
		cout << "Seleccione una opcion: ";
		cin >> opcion;
		
		// limpiar el buffer de entrada para evitar errores
		cin.ignore();
		
		switch (opcion) {
		case 1: {
			cout << "\n--- REGISTRAR EMPLEADO ---\n";
			string nombre, id, puesto;
			int tipoEmpleado = 0;
			
			cout << "Ingrese Cedula: ";
			getline(cin, id);
			cout << "Ingrese Nombre: ";
			getline(cin, nombre);
			
			cout << "Seleccione el tipo de empleado:\n";
			cout << "1. Medico\n";
			cout << "2. Enfermero\n";
			cout << "3. Administrativo\n";
			cout << "Opcion: ";
			cin >> tipoEmpleado;
			cin.ignore();
			//
			// Aqu� instancia la clase hija correspondiente seg�n la opci�n
			//
			if (tipoEmpleado == 1) {
				double salarioBase, pagoPorGuardia;
				int guardiasRealizadas;
				
				cout << "\n--- Registro de Medico ---\n";
				cout << "Ingrese Salario Base: ";
				cin >> salarioBase;
				cout << "Ingrese Cantidad de Guardias Realizadas: ";
				cin >> guardiasRealizadas;
				cout << "Ingrese Pago por Guardia: ";
				cin >> pagoPorGuardia;
				
				// 1. Crear el objeto Medico 
				Medico* nuevoMedico = new Medico(id, nombre, salarioBase, guardiasRealizadas, pagoPorGuardia);
				
				listaMedicos.agregar(nuevoMedico);
				listaEmpleados.agregar(nuevoMedico);
				cout << "[Funcion simulada] Medico agregado correctamente.\n";
			} 
			else if (tipoEmpleado == 2) {
				double salarioBase;
				int guardiasNocturnas, horasExtra;
				
				cout << "\n--- Registro de Enfermero ---\n";
				cout << "Ingrese Salario Base: ";
				cin >> salarioBase;
				cout << "Ingrese Cantidad de Guardias Nocturnas: ";
				cin >> guardiasNocturnas;
				cout << "Ingrese Cantidad de Horas Extra: ";
				cin >> horasExtra;
				
				// 1. Creamos el objeto din�mico de tipo Enfermero*
				Enfermero* nuevoEnfermero = new Enfermero(id, nombre, salarioBase, guardiasNocturnas, horasExtra);
				
				listaEnfermeros.agregar(nuevoEnfermero);
				listaEmpleados.agregar(nuevoEnfermero);
				cout << "Enfermero agregado correctamente.\n";
			} 
			else if (tipoEmpleado == 3) {
				double salarioBase;
				int horasExtra;
				cout << "Ingrese Salario Base: ";
				cin >> salarioBase;
				cout << "Ingrese Cantidad de Horas Extra: ";
				cin >> horasExtra;
				
				// 1. Crear el objeto Administrador 
				Administrador* nuevoAdmin = new Administrador(id, nombre, salarioBase, horasExtra);
				
				listaAdmins.agregar(nuevoAdmin);
				listaEmpleados.agregar(nuevoAdmin);
				cout << "[Funcion simulada] Administrativo agregado correctamente.\n";
			} 
			else {
				cout << "Opcion de tipo invalida.\n";
			}
			break;
		}
		case 2: {
			cout << "\n--- LISTA DE EMPLEADOS REGISTRADOS ---\n";
			// Aqu� llamar al m�todo de mostrar de tu lista de empleados.
			listaEmpleados.mostrar();
			cout << "Mostrando empleados de la lista...\n";
			system("pause");
			break;
		}
		case 3: {
			cout << "\n--- CALCULO DE SALARIOS ---\n";
			string idBuscado;
			cout << "Ingrese la cedula del empleado para calcular salario: ";
			getline(cin, idBuscado);
			
			bool encontrado = false;
			Empleado* empEncontrado = nullptr;
			
			// Recorremos la lista general usando los m�todos de ListaEmpleados
			for (int i = 0; i < listaEmpleados.getTamano(); i++) {
				Empleado* emp = listaEmpleados.obtener(i);
				if (emp != nullptr && emp->getId() == idBuscado) {
					empEncontrado = emp;
					encontrado = true;
					break; //buscamos la cedula
				}
			}
			
			if (encontrado && empEncontrado != nullptr) {
				cout << "\nEmpleado encontrado:\n";
				cout << "Cedula: " << empEncontrado->getId() << endl;
				cout << "Nombre: " << empEncontrado->getNombre() << endl;
				cout << "Salario Base: " << empEncontrado->getSalarioBase() << endl;
				
				double salarioTotal = empEncontrado->calcularSalarioNeto(); // calculo de salario
				cout << "Salario Total: " << salarioTotal << endl; //salario final
			} else {
				cout << "\nNo se encontro ningun empleado con la cedula: " << idBuscado << endl;
			}
			
			break;
		}
		case 4: {
			cout << "\n--- GUARDAR DATOS EN ARCHIVO DE TEXTO ---\n";
			ofstream archivo("README.txt");
			
			
			for (int i = 0; i < listaEmpleados.getTamano(); i++) {
				Empleado* emp = listaEmpleados.obtener(i);
				if (emp != nullptr) {
					archivo << emp->getId() << "\n" 
						<< emp->getNombre() << "\n" 
						<< emp->getSalarioBase() << "\n";
				}
			}
			archivo.close();
			cout << "Datos guardados exitosamente \n";
			break;
		}
		case 5:
			cout << "\nSaliendo del sistema de planilla.\n";
			break;
		default:
			cout << "\nOpcion invalida. Intente de nuevo.\n";
		}
		
	} while (opcion != 5);
	
	return 0;
}
