#include "ListaMedico.h"
#include <iostream>

using namespace std;

ListaMedico::ListaMedico() {
	cabeza = nullptr;
	tamano = 0;
}

ListaMedico::~ListaMedico() {
	NodoMedico* actual = cabeza;
	while (actual != nullptr) {
		NodoMedico* siguiente = actual->getSiguiente();
		delete actual; // Libera el nodo y el m�dico gracias al destructor de NodoMedico
		actual = siguiente;
	}
}

bool ListaMedico::estaVacia() const {
	return cabeza == nullptr;
}

int ListaMedico::getTamano() const {
	return tamano;
}

// Inserci�n din�mica al final de la lista
void ListaMedico::agregar(Medico* nuevoMedico) {
	NodoMedico* nuevoNodo = new NodoMedico(nuevoMedico);
	
	if (estaVacia()) {
		cabeza = nuevoNodo;
	} else {
		NodoMedico* actual = cabeza;
		while (actual->getSiguiente() != nullptr) {
			actual = actual->getSiguiente();
		}
		actual->setSiguiente(nuevoNodo);
	}
	tamano++;
}

// Eliminar un nodo buscando por ID
bool ListaMedico::eliminar(string id) {
	if (estaVacia()) return false;
	
	NodoMedico* actual = cabeza;
	NodoMedico* anterior = nullptr;
	
	// Si el elemento a eliminar es la cabeza
	if (actual->getDato()->getId() == id) {
		cabeza = cabeza->getSiguiente();
		delete actual;
		tamano--;
		return true;
	}
	
	while (actual != nullptr && actual->getDato()->getId() != id) {
		anterior = actual;
		actual = actual->getSiguiente();
	}
	
	if (actual == nullptr) return false; // No se encontr�
	
	anterior->setSiguiente(actual->getSiguiente());
	delete actual;
	tamano--;
	return true;
}

// Obtener por posici�n (�ndice)
Medico* ListaMedico::obtener(int index) const {
	if (index < 0 || index >= tamano) return nullptr;
	
	NodoMedico* actual = cabeza;
	int contador = 0;
	while (actual != nullptr && contador < index) {
		actual = actual->getSiguiente();
		contador++;
	}
	return (actual != nullptr) ? actual->getDato() : nullptr;
}

// Recorrido de la lista
void ListaMedico::mostrar() const {
	NodoMedico* actual = cabeza;
	
	if (actual == nullptr) {
		cout << "No hay medicos registrados.\n";
		return;
	}
	
	while (actual != nullptr) {
		
		
		// Opci�n B: Imprimiendo directamente con los getters de Medico / Empleado:
		cout << "ID: " << actual->getDato()->getId() 
			<< " | Nombre: " << actual->getDato()->getNombre() 
			<< " | Salario Base: " << actual->getDato()->getSalarioBase() << endl;
		
		actual = actual->getSiguiente();
	}
}
