#include "ListaAdmin.h"
#include <iostream>

using namespace std;

ListaAdmin::ListaAdmin() {
	cabeza = nullptr;
	tamano = 0;
}

ListaAdmin::~ListaAdmin() {
	NodoAdmin* actual = cabeza;
	while (actual != nullptr) {
		NodoAdmin* siguiente = actual->getSiguiente();
		delete actual; // Libera el nodo y el administrador gracias al destructor de NodoAdmin
		actual = siguiente;
	}
}

bool ListaAdmin::estaVacia() const {
	return cabeza == nullptr;
}

int ListaAdmin::getTamano() const {
	return tamano;
}

// Inserci�n din�mica al final de la lista
void ListaAdmin::agregar(Administrador* nuevoAdmin) {
	NodoAdmin* nuevoNodo = new NodoAdmin(nuevoAdmin);
	
	if (estaVacia()) {
		cabeza = nuevoNodo;
	} else {
		NodoAdmin* actual = cabeza;
		while (actual->getSiguiente() != nullptr) {
			actual = actual->getSiguiente();
		}
		actual->setSiguiente(nuevoNodo);
	}
	tamano++;
}

// Eliminar un nodo buscando por ID
bool ListaAdmin::eliminar(string id) {
	if (estaVacia()) return false;
	
	NodoAdmin* actual = cabeza;
	NodoAdmin* anterior = nullptr;
	
	// Si el elemento a eliminar es la cabeza
	if (actual->getDato()->getId() == id) {
		cabeza = cabeza->getSiguiente();
		delete actual;
		tamano--;
		return true;
	}
	
	while (actual != nullptr && actual->getDato()->getId() != id) {
		anterior = actual;
		actual = actual->getSiguiente();
	}
	
	if (actual == nullptr) return false; // No se encontr�
	
	anterior->setSiguiente(actual->getSiguiente());
	delete actual;
	tamano--;
	return true;
}

// Obtener por posici�n (�ndice)
Administrador* ListaAdmin::obtener(int index) const {
	if (index < 0 || index >= tamano) return nullptr;
	
	NodoAdmin* actual = cabeza;
	int contador = 0;
	while (actual != nullptr && contador < index) {
		actual = actual->getSiguiente();
		contador++;
	}
	return (actual != nullptr) ? actual->getDato() : nullptr;
}

// Recorrido de la lista
void ListaAdmin::mostrar() const {
	NodoAdmin* actual = cabeza;
	while (actual != nullptr) {
		// Aqu� puedes invocar m�todos de visualizaci�n del Administrador si lo deseas
		actual = actual->getSiguiente();
	}
}
