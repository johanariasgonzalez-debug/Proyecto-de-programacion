#ifndef LISTAENFERMERO_H
#define LISTAENFERMERO_H

#include "NodoEnfermero.h"
#include <string>

using namespace std;

class ListaEnfermero {
private:
	NodoEnfermero* cabeza;
	int tamano;
	
public:
	ListaEnfermero();
	~ListaEnfermero();
	
	bool estaVacia() const;
	int getTamano() const;
	
	void agregar(Enfermero* nuevoEnfermero); // Inserci�n din�mica
	bool eliminar(string id);                // Eliminar por ID
	Enfermero* obtener(int index) const;     // Obtener por posici�n
	void mostrar() const;                    // Recorrido
};

#endif
