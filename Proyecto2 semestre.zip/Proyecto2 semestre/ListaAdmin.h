#ifndef LISTAADMIN_H
#define LISTAADMIN_H

#include "NodoAdmin.h"
#include <string>

using namespace std;

class ListaAdmin {
private:
	NodoAdmin* cabeza;
	int tamano;
	
public:
	ListaAdmin();
	~ListaAdmin();
	
	bool estaVacia() const;
	int getTamano() const;
	
	void agregar(Administrador* nuevoAdmin); // Inserci�n din�mica
	bool eliminar(string id);                // Eliminar por ID
	Administrador* obtener(int index) const; // Obtener por posici�n
	void mostrar() const;                    // Recorrido
};

#endif
