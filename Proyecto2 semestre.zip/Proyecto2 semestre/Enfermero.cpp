#include "Enfermero.h"

Enfermero::Enfermero(string _id, string _nombre, double _salarioBase,int _Guardias,int _Extras)
	: Empleado(_id, _nombre, _salarioBase) {
	GuardiasNocturnas = _Guardias;
	HorasExtra = _Extras;
	
}

Enfermero::~Enfermero() {
	
}

double Enfermero::calcularSalarioBruto() {
	return salarioBase + (GuardiasNocturnas * HorasExtra);
}

double Enfermero::calcularDeducciones() {
	// Ejemplo: 9.34% CCSS + 5% impuesto
	return calcularSalarioBruto() * 0.1434;
}

double Enfermero::calcularSalarioNeto() {
	return calcularSalarioBruto() - calcularDeducciones();
}
