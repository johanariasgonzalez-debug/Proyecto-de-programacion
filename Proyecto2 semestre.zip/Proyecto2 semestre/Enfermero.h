#ifndef ENFERMERO_H
#define ENFERMERO_H
#include "Empleado.h"
class Enfermero: public Empleado {
private:
int GuardiasNocturnas;
int HorasExtra;
public:
	Enfermero(string _id, string _nombre, double _salarioBase,int GuardiasNocturnas,int HorasExtra);
	~Enfermero();
	// Sobrescritura de m�todos virtuales (Polimorfismo)
	double calcularSalarioBruto() override;
	double calcularDeducciones() override;
	double calcularSalarioNeto() override;
};

#endif

