#include "Administrador.h"

Administrador::Administrador(string _id, string _nombre, double _salarioBase,int _Extras)
	: Empleado(_id, _nombre, _salarioBase) {
	HorasExtra = _Extras;
}

Administrador::~Administrador() {
	
}
double Administrador::calcularSalarioBruto() {
	return salarioBase + (HorasExtra);
}

double Administrador::calcularDeducciones() {
	// Ejemplo: 9.34% CCSS + 5% impuesto
	return calcularSalarioBruto() * 0.1434;
}

double Administrador::calcularSalarioNeto() {
	return calcularSalarioBruto() - calcularDeducciones();
}
