#ifndef ADMINISTRADOR_H
#define ADMINISTRADOR_H
#include "Empleado.h"
class Administrador: public Empleado {
private:
	int HorasExtra;
public:
	Administrador(string _id, string _nombre, double _salarioBase,int HorasExtra);
	~Administrador();
	
	// Sobrescritura de m�todos virtuales (Polimorfismo)
	double calcularSalarioBruto() override;
	double calcularDeducciones() override;
	double calcularSalarioNeto() override;
};

#endif

