#include "NodoEnfermero.h"

NodoEnfermero::NodoEnfermero(Enfermero* enf) {
	dato = enf;
	siguiente = nullptr;
}

NodoEnfermero::~NodoEnfermero() {
	delete dato; 
}

void NodoEnfermero::setDato(Enfermero* enf) { dato = enf; }
Enfermero* NodoEnfermero::getDato() const { return dato; }

void NodoEnfermero::setSiguiente(NodoEnfermero* sig) { siguiente = sig; }
NodoEnfermero* NodoEnfermero::getSiguiente() const { return siguiente; }
