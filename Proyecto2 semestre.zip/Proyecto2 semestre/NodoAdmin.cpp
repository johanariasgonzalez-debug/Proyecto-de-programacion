#include "NodoAdmin.h"

NodoAdmin::NodoAdmin(Administrador* adm) {
	dato = adm;
	siguiente = nullptr;
}

NodoAdmin::~NodoAdmin() {
	delete dato; 
}

void NodoAdmin::setDato(Administrador* adm) { dato = adm; }
Administrador* NodoAdmin::getDato() const { return dato; }

void NodoAdmin::setSiguiente(NodoAdmin* sig) { siguiente = sig; }
NodoAdmin* NodoAdmin::getSiguiente() const { return siguiente; }
