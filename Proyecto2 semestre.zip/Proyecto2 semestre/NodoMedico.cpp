#include "NodoMedico.h"

NodoMedico::NodoMedico(Medico* med) {
	dato = med;
	siguiente = nullptr;
}

NodoMedico::~NodoMedico() {
	delete dato; 
}

void NodoMedico::setDato(Medico* med) { dato = med; }
Medico* NodoMedico::getDato() const { return dato; }

void NodoMedico::setSiguiente(NodoMedico* sig) { siguiente = sig; }
NodoMedico* NodoMedico::getSiguiente() const { return siguiente; }
