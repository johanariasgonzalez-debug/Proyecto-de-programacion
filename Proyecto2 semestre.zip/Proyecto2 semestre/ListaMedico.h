#ifndef LISTAMEDICO_H
#define LISTAMEDICO_H

#include "NodoMedico.h"
#include <string>

using namespace std;

class ListaMedico {
private:
	NodoMedico* cabeza;
	int tamano;
	
public:
	ListaMedico();
	~ListaMedico();
	
	bool estaVacia() const;
	int getTamano() const;
	
	void agregar(Medico* nuevoMedico); // Inserci�n din�mica
	bool eliminar(string id);                // Eliminar por ID
	Medico* obtener(int index) const;     // Obtener por posici�n
	void mostrar() const;                    // Recorrido
};

#endif
