#ifndef NODOENFERMERO_H
#define NODOENFERMERO_H

#include "Enfermero.h"

class NodoEnfermero {
private:
	Enfermero* dato;        // puntero a la clase Enfermero
	NodoEnfermero* siguiente;
	
public:
	// Constructor y Destructor
	NodoEnfermero(Enfermero* enf);
	~NodoEnfermero();
	
	// M�todos Getters y Setters
	void setDato(Enfermero* enf);
	Enfermero* getDato() const;
	
	void setSiguiente(NodoEnfermero* sig);
	NodoEnfermero* getSiguiente() const;
};

#endif
