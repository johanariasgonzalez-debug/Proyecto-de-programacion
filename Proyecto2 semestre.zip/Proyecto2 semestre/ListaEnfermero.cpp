#include "ListaEnfermero.h"
#include <iostream>

using namespace std;

ListaEnfermero::ListaEnfermero() {
	cabeza = nullptr;
	tamano = 0;
}

ListaEnfermero::~ListaEnfermero() {
	NodoEnfermero* actual = cabeza;
	while (actual != nullptr) {
		NodoEnfermero* siguiente = actual->getSiguiente();
		delete actual; // Libera el nodo y el enfermero gracias al destructor de NodoEnfermero
		actual = siguiente;
	}
}

bool ListaEnfermero::estaVacia() const {
	return cabeza == nullptr;
}

int ListaEnfermero::getTamano() const {
	return tamano;
}

// Inserci�n din�mica al final de la lista
void ListaEnfermero::agregar(Enfermero* nuevoEnfermero) {
	NodoEnfermero* nuevoNodo = new NodoEnfermero(nuevoEnfermero);
	
	if (estaVacia()) {
		cabeza = nuevoNodo;
	} else {
		NodoEnfermero* actual = cabeza;
		while (actual->getSiguiente() != nullptr) {
			actual = actual->getSiguiente();
		}
		actual->setSiguiente(nuevoNodo);
	}
	tamano++;
}

// Eliminar un nodo buscando por ID
bool ListaEnfermero::eliminar(string id) {
	if (estaVacia()) return false;
	
	NodoEnfermero* actual = cabeza;
	NodoEnfermero* anterior = nullptr;
	
	// Si el elemento a eliminar es la cabeza
	if (actual->getDato()->getId() == id) {
		cabeza = cabeza->getSiguiente();
		delete actual;
		tamano--;
		return true;
	}
	
	while (actual != nullptr && actual->getDato()->getId() != id) {
		anterior = actual;
		actual = actual->getSiguiente();
	}
	
	if (actual == nullptr) return false; // No se encontr�
	
	anterior->setSiguiente(actual->getSiguiente());
	delete actual;
	tamano--;
	return true;
}

// Obtener por posici�n (�ndice)
Enfermero* ListaEnfermero::obtener(int index) const {
	if (index < 0 || index >= tamano) return nullptr;
	
	NodoEnfermero* actual = cabeza;
	int contador = 0;
	while (actual != nullptr && contador < index) {
		actual = actual->getSiguiente();
		contador++;
	}
	return (actual != nullptr) ? actual->getDato() : nullptr;
}

// Recorrido de la lista
void ListaEnfermero::mostrar() const {
	NodoEnfermero* actual = cabeza;
	while (actual != nullptr) {
		// Aqu� puedes invocar m�todos de visualizaci�n del Enfermero si lo deseas
		actual = actual->getSiguiente();
	}
}
