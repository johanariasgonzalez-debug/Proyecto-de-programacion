#ifndef NODOMEDICO_H
#define NODOMEDICO_H

#include "Medico.h"

class NodoMedico {
private:
	Medico* dato;        // puntero a la clase Medico
	NodoMedico* siguiente;
	
public:
	// Constructor y Destructor
	NodoMedico(Medico* med);
	~NodoMedico();
	
	// M�todos Getters y Setters
	void setDato(Medico* med);
	Medico* getDato() const;
	
	void setSiguiente(NodoMedico* sig);
	NodoMedico* getSiguiente() const;
};

#endif
