#ifndef NODOADMIN_H
#define NODOADMIN_H
#include "Administrador.h"

class NodoAdmin {
private:
	Administrador* dato;        // puntero a la clase Administrador
	NodoAdmin* siguiente;
	
public:
	// Constructor y Destructor
	NodoAdmin(Administrador* adm);
	~NodoAdmin();
	
	// M�todos Getters y Setters
	void setDato(Administrador* adm);
	Administrador* getDato() const;
	
	void setSiguiente(NodoAdmin* sig);
	NodoAdmin* getSiguiente() const;
};

#endif
